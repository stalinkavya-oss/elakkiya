# VS Code Setup

## 1. Open the project
Open the `PocketSmartAI` folder in VS Code.

## 2. Create a virtual environment

Windows PowerShell:
```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
```

Windows CMD:
```cmd
py -3.11 -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

## 3. Install dependencies
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 4. Configure Gemini
Copy `.env.example` to `.env` and set:
```env
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```

The supplied document specifies Gemini 1.5 Flash Pro, but that is now a legacy model. This implementation uses a current configurable Gemini model by default.

## 5. Run
```bash
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## 6. Test
Open `/docs` for FastAPI's interactive API documentation, or use the web interface.

Health endpoint:
```text
GET /health
```

The application also works without a Gemini API key by using deterministic local fallback recommendations.
