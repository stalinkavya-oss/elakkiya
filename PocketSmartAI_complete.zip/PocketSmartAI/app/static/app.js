function renderResult(data) {
    const element = document.querySelector("#result");
    if (!element) return;

    element.classList.remove("hidden");

    const items = data.items || [];

    element.innerHTML = `
        <h2>Your ${data.planner} plan</h2>
        <div class="summary">
            <b>Budget: ₹${Number(data.budget).toLocaleString("en-IN")}</b>
            <p>${data.summary || ""}</p>
            <strong>Allocation</strong>
            <pre>${JSON.stringify(data.allocation || {}, null, 2)}</pre>
        </div>
        <h3>Suggestions</h3>
        <div class="result-grid">
            ${items.map(item => `
                <article class="rec">
                    <b>${item.name}</b>
                    <p>${item.description}</p>
                    <small>${item.category} · ${item.platform}</small>
                    <p><strong>Est. ₹${Number(item.estimated_price || 0).toLocaleString("en-IN")}</strong></p>
                    <a target="_blank" rel="noopener" href="${item.url}">Open platform search →</a>
                </article>
            `).join("")}
        </div>
    `;

    element.scrollIntoView({behavior: "smooth"});
}

async function submitPlanner(form) {
    const config = window.plannerConfig;
    if (!config) return;

    const formData = new FormData(form);
    let options = {method: "POST"};

    if (config.type === "jewelry") {
        options.body = formData;
    } else {
        const data = {};

        formData.forEach((value, key) => {
            if (key === "rooms") {
                data.rooms = [...(data.rooms || []), value];
            } else if (key === "budget" || key === "guests") {
                data[key] = Number(value);
            } else {
                data[key] = value;
            }
        });

        options.headers = {"Content-Type": "application/json"};
        options.body = JSON.stringify(data);
    }

    const response = await fetch(config.url, options);
    const data = await response.json();

    if (!response.ok) {
        alert(data.detail || "Something went wrong");
        return;
    }

    renderResult(data);
}

document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("#planner-form");

    if (form) {
        form.addEventListener("submit", (event) => {
            event.preventDefault();
            submitPlanner(form);
        });
    }
});
