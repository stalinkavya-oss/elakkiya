from datetime import datetime, timedelta, timezone

from jose import jwt, JWTError
from passlib.context import CryptContext
from fastapi import Request

from .config import settings
from .database import get_conn

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
ALGORITHM = "HS256"

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(password, hashed)

def create_token(user_id: int) -> str:
    payload = {
        "sub": str(user_id),
        "exp": datetime.now(timezone.utc) + timedelta(hours=24),
    }
    return jwt.encode(payload, settings.secret_key, algorithm=ALGORITHM)

def current_user(request: Request):
    token = request.cookies.get("access_token")
    if not token:
        return None

    try:
        user_id = int(
            jwt.decode(
                token,
                settings.secret_key,
                algorithms=[ALGORITHM]
            )["sub"]
        )
    except (JWTError, ValueError, TypeError):
        return None

    with get_conn() as c:
        row = c.execute(
            "SELECT id,name,email FROM users WHERE id=?",
            (user_id,)
        ).fetchone()

    return dict(row) if row else None
