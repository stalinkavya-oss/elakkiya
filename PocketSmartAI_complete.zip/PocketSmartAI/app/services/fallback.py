from .catalog import platform_url

def home_fallback(data):
    budget = data["budget"]
    rooms = data["rooms"]
    per_room = budget / len(rooms)
    items = []

    for room in rooms:
        choices = [
            ("Furniture", f"{room} storage unit",
             "Practical storage for the selected room.",
             per_room * 0.38, "IKEA"),
            ("Lighting", f"{room} LED light",
             "Energy-efficient decorative lighting.",
             per_room * 0.12, "Amazon"),
            ("Decor", f"{room} wall decor set",
             "Simple decor to complement the room style.",
             per_room * 0.10, "Flipkart"),
        ]

        for cat, name, desc, price, platform in choices:
            items.append({
                "category": cat,
                "name": name,
                "description": desc,
                "estimated_price": round(price, 2),
                "platform": platform,
                "url": platform_url(platform, name),
            })

    return {
        "planner": "home",
        "budget": budget,
        "allocation": {"rooms": round(budget, 2)},
        "summary": (
            f"Starter {data['style']} plan for {len(rooms)} room(s), "
            "kept within the stated budget."
        ),
        "items": items,
    }

def party_fallback(data):
    b = data["budget"]
    g = data["guests"]

    alloc = {
        "food": round(b * 0.50, 2),
        "decoration": round(b * 0.20, 2),
        "venue": round(b * 0.20, 2),
        "entertainment": round(b * 0.10, 2),
    }

    specs = [
        ("Food", "Catering / food package",
         "Food planning sized for the guest count.",
         alloc["food"], "Swiggy"),
        ("Food", "Restaurant options",
         "Browse restaurant options.",
         alloc["food"] * 0.4, "Zomato"),
        ("Venue", f"{data['venue']} venue",
         "Venue allowance for the event.",
         alloc["venue"], "OYO"),
        ("Decoration", "Party decoration kit",
         "Theme-friendly decoration starter kit.",
         alloc["decoration"], "Amazon"),
        ("Entertainment", "Party entertainment",
         "Budget allowance for simple entertainment.",
         alloc["entertainment"], "Amazon"),
    ]

    items = [
        {
            "category": c,
            "name": n,
            "description": d,
            "estimated_price": round(p, 2),
            "platform": pl,
            "url": platform_url(pl, n),
        }
        for c, n, d, p, pl in specs
    ]

    return {
        "planner": "party",
        "budget": b,
        "allocation": alloc,
        "summary": f"Plan for {g} guests at approximately {round(b/g, 2)} per guest.",
        "items": items,
    }

def jewelry_fallback(data):
    b = data["budget"]

    items = [
        {
            "category": "Necklace",
            "name": "Occasion necklace set",
            "description": f"{data['style'].title()} style for a {data['occasion']} occasion.",
            "estimated_price": round(b * 0.45, 2),
            "platform": "Amazon",
        },
        {
            "category": "Earrings",
            "name": "Matching earrings",
            "description": "Coordinated earrings for the selected outfit.",
            "estimated_price": round(b * 0.20, 2),
            "platform": "Flipkart",
        },
        {
            "category": "Bangles",
            "name": "Bangle set",
            "description": "A complementary bangle option.",
            "estimated_price": round(b * 0.15, 2),
            "platform": "Amazon",
        },
        {
            "category": "Jewelry set",
            "name": "Complete matching set",
            "description": "A broader set for a coordinated look.",
            "estimated_price": round(b * 0.18, 2),
            "platform": "Flipkart",
        },
    ]

    for item in items:
        item["url"] = platform_url(item["platform"], item["name"])

    return {
        "planner": "jewelry",
        "budget": b,
        "allocation": {
            "necklace": round(b * 0.45, 2),
            "earrings": round(b * 0.20, 2),
            "bangles": round(b * 0.15, 2),
            "set": round(b * 0.18, 2),
        },
        "summary": (
            f"Starter {data['style']} jewelry plan for a "
            f"{data['occasion']} occasion. Outfit color: "
            f"{data.get('outfit_color') or 'not specified'}."
        ),
        "items": items,
    }
