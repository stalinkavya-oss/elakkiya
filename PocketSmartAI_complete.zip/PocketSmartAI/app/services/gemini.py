import json

from google import genai
from google.genai import types

from .fallback import home_fallback, party_fallback, jewelry_fallback
from ..config import settings

class GeminiService:
    def __init__(self):
        self.client = (
            genai.Client(api_key=settings.gemini_api_key)
            if settings.gemini_api_key
            else None
        )

    def _generate(self, prompt, image_bytes=None, mime_type=None):
        if not self.client:
            return None

        contents = [prompt]

        if image_bytes and mime_type:
            contents.append(
                types.Part.from_bytes(
                    data=image_bytes,
                    mime_type=mime_type
                )
            )

        response = self.client.models.generate_content(
            model=settings.gemini_model,
            contents=contents,
            config=types.GenerateContentConfig(
                temperature=0.4,
                response_mime_type="application/json",
            ),
        )
        return json.loads(response.text)

    def home(self, data):
        prompt = f"""
You are PocketSmart AI, a budget-aware home interior recommendation assistant.
Return ONLY valid JSON with keys:
planner,budget,allocation,summary,items.
items must be a list of objects with:
category,name,description,estimated_price,platform,url.

Budget: {data['budget']}
Rooms: {data['rooms']}
Style: {data['style']}
Notes: {data['notes']}

Use only these platform names: Amazon, Flipkart, IKEA.
Prices are estimates, not live prices.
"""
        try:
            return self._generate(prompt) or home_fallback(data)
        except Exception:
            return home_fallback(data)

    def party(self, data):
        prompt = f"""
You are PocketSmart AI, a party budget planner.
Return ONLY JSON with:
planner,budget,allocation,summary,items.
Budget: {data['budget']}
Guests: {data['guests']}
Event: {data['event_type']}
Venue: {data['venue']}
City: {data['city']}
Notes: {data['notes']}

Allocate budget across food, decoration, venue, entertainment.
Use platform names Swiggy, Zomato, OYO, Amazon only.
Prices are estimates.
"""
        try:
            return self._generate(prompt) or party_fallback(data)
        except Exception:
            return party_fallback(data)

    def jewelry(self, data, image_bytes=None, mime_type=None):
        prompt = f"""
You are PocketSmart AI, a jewelry budget planner.
Return ONLY JSON with:
planner,budget,allocation,summary,items.
Budget: {data['budget']}
Occasion: {data['occasion']}
Style: {data['style']}
Outfit color: {data['outfit_color']}
Notes: {data['notes']}

If an outfit image is attached, consider visible colors and style.
Use Amazon and Flipkart only.
Prices are estimates, not live prices.
"""
        try:
            return (
                self._generate(prompt, image_bytes, mime_type)
                or jewelry_fallback(data)
            )
        except Exception:
            return jewelry_fallback(data)

gemini_service = GeminiService()
