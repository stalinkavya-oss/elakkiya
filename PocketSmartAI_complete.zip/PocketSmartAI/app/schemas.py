from typing import List
from pydantic import BaseModel, EmailStr, Field

class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class HomeRequest(BaseModel):
    budget: float = Field(gt=0)
    rooms: List[str] = Field(min_length=1)
    style: str = "modern"
    notes: str = ""

class PartyRequest(BaseModel):
    budget: float = Field(gt=0)
    guests: int = Field(gt=0, le=10000)
    event_type: str = "birthday"
    venue: str = "home"
    city: str = ""
    notes: str = ""

class JewelryRequest(BaseModel):
    budget: float = Field(gt=0)
    occasion: str = "wedding"
    style: str = "traditional"
    outfit_color: str = ""
    notes: str = ""
