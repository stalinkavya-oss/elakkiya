import json
from pathlib import Path

from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.templating import Jinja2Templates

from .config import settings
from .database import init_db, get_conn
from .auth import hash_password, verify_password, create_token, current_user
from .schemas import RegisterIn, LoginIn, HomeRequest, PartyRequest
from .services.gemini import gemini_service

BASE = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE / "templates"))

app = FastAPI(title=settings.app_name, version="1.0.0")
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def startup():
    init_db()

def page_context(request: Request, **kwargs):
    return {"request": request, "user": current_user(request), **kwargs}

def save_result(request, planner, payload, result):
    user = current_user(request)
    if not user:
        return

    with get_conn() as c:
        c.execute(
            """
            INSERT INTO recommendations
            (user_id, planner, request_json, result_json)
            VALUES (?, ?, ?, ?)
            """,
            (
                user["id"],
                planner,
                json.dumps(payload),
                json.dumps(result),
            ),
        )

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("index.html", page_context(request))

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", page_context(request))

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", page_context(request))

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    user = current_user(request)
    if not user:
        return RedirectResponse("/login", status_code=303)
    return templates.TemplateResponse("dashboard.html", page_context(request))

@app.get("/planner/{kind}", response_class=HTMLResponse)
def planner(request: Request, kind: str):
    if kind not in {"home", "party", "jewelry"}:
        raise HTTPException(404, "Planner not found")

    if not current_user(request):
        return RedirectResponse("/login", status_code=303)

    return templates.TemplateResponse(
        f"{kind}_planner.html",
        page_context(request, kind=kind),
    )

@app.get("/history", response_class=HTMLResponse)
def history(request: Request):
    user = current_user(request)
    if not user:
        return RedirectResponse("/login", status_code=303)

    with get_conn() as c:
        rows = c.execute(
            """
            SELECT * FROM recommendations
            WHERE user_id=?
            ORDER BY id DESC
            """,
            (user["id"],),
        ).fetchall()

    return templates.TemplateResponse(
        "history.html",
        page_context(request, rows=[dict(row) for row in rows]),
    )

@app.post("/api/auth/register")
def register(data: RegisterIn):
    with get_conn() as c:
        exists = c.execute(
            "SELECT id FROM users WHERE email=?",
            (data.email,),
        ).fetchone()

        if exists:
            raise HTTPException(400, "Email already registered")

        c.execute(
            """
            INSERT INTO users(name,email,password_hash)
            VALUES(?,?,?)
            """,
            (data.name, data.email, hash_password(data.password)),
        )

    return {"message": "Registration successful"}

@app.post("/api/auth/login")
def login(data: LoginIn):
    with get_conn() as c:
        row = c.execute(
            "SELECT * FROM users WHERE email=?",
            (data.email,),
        ).fetchone()

    if not row or not verify_password(data.password, row["password_hash"]):
        raise HTTPException(401, "Invalid email or password")

    response = RedirectResponse("/dashboard", status_code=303)
    response.set_cookie(
        "access_token",
        create_token(row["id"]),
        httponly=True,
        samesite="lax",
        secure=False,
        max_age=86400,
    )
    return response

@app.post("/logout")
def logout():
    response = RedirectResponse("/", status_code=303)
    response.delete_cookie("access_token")
    return response

@app.post("/api/generate-home")
def generate_home(request: Request, data: HomeRequest):
    payload = data.model_dump()
    result = gemini_service.home(payload)
    save_result(request, "home", payload, result)
    return result

@app.post("/api/generate-party")
def generate_party(request: Request, data: PartyRequest):
    payload = data.model_dump()
    result = gemini_service.party(payload)
    save_result(request, "party", payload, result)
    return result

@app.post("/api/generate-jewelry")
async def generate_jewelry(
    request: Request,
    budget: float = Form(...),
    occasion: str = Form(...),
    style: str = Form(...),
    outfit_color: str = Form(""),
    notes: str = Form(""),
    outfit: UploadFile | None = File(None),
):
    if budget <= 0:
        raise HTTPException(422, "Budget must be greater than zero")

    image_bytes = None
    mime_type = None

    if outfit and outfit.filename:
        allowed = {"image/jpeg", "image/png", "image/webp"}

        if outfit.content_type not in allowed:
            raise HTTPException(400, "Use JPG, PNG or WEBP")

        image_bytes = await outfit.read()

        if len(image_bytes) > 5 * 1024 * 1024:
            raise HTTPException(400, "Image must be 5 MB or smaller")

        mime_type = outfit.content_type

    payload = {
        "budget": budget,
        "occasion": occasion,
        "style": style,
        "outfit_color": outfit_color,
        "notes": notes,
    }

    result = gemini_service.jewelry(
        payload,
        image_bytes,
        mime_type,
    )

    save_result(request, "jewelry", payload, result)
    return result

@app.get("/api/session-info")
def session_info(request: Request):
    user = current_user(request)
    return {"logged_in": bool(user), "user": user}

@app.get("/api/history")
def api_history(request: Request):
    user = current_user(request)

    if not user:
        raise HTTPException(401, "Login required")

    with get_conn() as c:
        rows = c.execute(
            """
            SELECT planner,request_json,result_json,created_at
            FROM recommendations
            WHERE user_id=?
            ORDER BY id DESC
            """,
            (user["id"],),
        ).fetchall()

    return [dict(row) for row in rows]

@app.get("/health")
def health():
    return {"status": "ok", "app": settings.app_name}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
