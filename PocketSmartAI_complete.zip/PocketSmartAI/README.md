# PocketSmart AI

A complete FastAPI + Jinja2 + SQLite + Gemini recommendation assistant based on the supplied project documentation.

Features:
- Register/login/logout with JWT cookie authentication
- Home, Party, and Jewelry budget planners
- Optional jewelry outfit image sent to Gemini
- Structured AI recommendations
- Recommendation history
- Local fallback recommendations when Gemini is not configured

Quick start:
1. Create a Python 3.11+ virtual environment.
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env`
4. Add `GEMINI_API_KEY` for live AI
5. `uvicorn app.main:app --reload`
6. Open http://127.0.0.1:8000

See SETUP.md for detailed VS Code instructions.
